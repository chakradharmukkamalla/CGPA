import React, { useState } from "react";
import "./gpa.css";

function gpa() {
  const [subjects, setSubjects] = useState([{ subjectName: "", credits: "", grade: "" }]);
  const [gpa, setGpa] = useState(null);
   

  // Updated Grade-to-point mapping (case-insensitive)
  const gradePoints = {
    S: 10,
    A: 9,
    B: 8,
    C: 7,
    D: 6,
    E: 5,
    F: 0,
  };

  // Add a new subject input field
    const addSubject = () => {
        setSubjects([...subjects, { subjectName: "", credits: "", grade: "" }]);
    };

  // Handle input changes for each subject
  const handleSubjectChange = (index, e) => {
    const updatedSubjects = [...subjects];
    updatedSubjects[index][e.target.name] = e.target.value;
    setSubjects(updatedSubjects);
  };

  // Handle delete subject
  const deleteSubject = (index) => {
    const updatedSubjects = subjects.filter((_, i) => i !== index);
    setSubjects(updatedSubjects);
  };

  // Calculate GPA based on the subjects and grades entered
  const calculateGpa = (e) => {
    e.preventDefault();
    let totalCredits = 0;
    let totalPoints = 0;

    subjects.forEach((subject) => {
      // Convert grade to uppercase to make comparison case-insensitive
      const grade = subject.grade.toUpperCase();
      const gradePoint = gradePoints[grade];

      if (gradePoint !== undefined && subject.credits && subject.grade) {
        totalCredits += parseFloat(subject.credits); // Allowing float values for credits
        totalPoints += gradePoint * parseFloat(subject.credits); // Multiply grade point by credit
      }
    });

    if (totalCredits === 0) {
      alert("Please add valid subjects with credits and grades.");
      return;
    }

    const calculatedGpa = totalPoints / totalCredits;
    setGpa(calculatedGpa.toFixed(2)); // Show GPA with 2 decimal places
  };

  return (
    <div className="gpa">
      <h1>VIT GPA Calculator</h1>
      <form onSubmit={calculateGpa}>
        {subjects.map((subject, index) => (
          <div key={index} className="subject">
            <input
              type="text"
              name="subjectName"
              placeholder="Subject Name"
              value={subject.subjectName}
              onChange={(e) => handleSubjectChange(index, e)}
              required
                />
            <input
              type="number"
              name="credits"
              placeholder="Credits"
              value={subject.credits}
              onChange={(e) => handleSubjectChange(index, e)}
              required
              min="0.1"
              step="0.1" // Allows decimal values
            />
            <input
              type="text"
              name="grade"
              placeholder="Grade (S, A, B, C, D, E, F)"
              value={subject.grade}
              onChange={(e) => handleSubjectChange(index, e)}
              required
            />
            <button type="button" onClick={() => deleteSubject(index)}>
              Delete
            </button>
            </div>
        ))}
        <button type="button" onClick={addSubject}>
          Add Subject
        </button>
        <button type="submit">Calculate GPA</button>
      </form>

      {gpa && (
        <div className="result">
          <h2>Your GPA: {gpa}</h2>
        </div>
      )}
    </div>
  );
}

export default gpa;
